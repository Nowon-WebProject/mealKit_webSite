package kr.co.EZHOME.dto;

public class AddrDTO {
	private int deli_addr_seq;
	private String userid;
	private String deli_name;
	private String deli_addr;
	private String deli_phone;
	private String deli_msg;
	private String deli_pwd;

	public AddrDTO() {
		
		
	}

	public int getDeli_addr_seq() {
		return deli_addr_seq;
	}

	public void setDeli_addr_seq(int deli_addr_seq) {
		this.deli_addr_seq = deli_addr_seq;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getDeli_name() {
		return deli_name;
	}

	public void setDeli_name(String deli_name) {
		this.deli_name = deli_name;
	}

	public String getDeli_addr() {
		return deli_addr;
	}

	public void setDeli_addr(String deli_addr) {
		this.deli_addr = deli_addr;
	}

	public String getDeli_phone() {
		return deli_phone;
	}

	public void setDeli_phone(String deli_phone) {
		this.deli_phone = deli_phone;
	}

	public String getDeli_msg() {
		return deli_msg;
	}

	public void setDeli_msg(String deli_msg) {
		this.deli_msg = deli_msg;
	}

	public String getDeli_pwd() {
		return deli_pwd;
	}

	public void setDeli_pwd(String deli_pwd) {
		this.deli_pwd = deli_pwd;
	}
	
	
	
	
	
}
