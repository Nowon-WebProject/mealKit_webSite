package kr.co.EZHOME.dto;

public class OrderDTO {
	private String order_num;
	private String userid;
	private int item_num;
	private String item_name;
	private int item_price;
	private int item_cnt;
	private String deli_status;
	private String refund_status;
	private int refund_request;

	public OrderDTO() {

	}

	public String getOrder_num() {
		return order_num;
	}

	public void setOrder_num(String order_num) {
		this.order_num = order_num;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getItem_num() {
		return item_num;
	}

	public void setItem_num(int item_num) {
		this.item_num = item_num;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}

	public int getItem_cnt() {
		return item_cnt;
	}

	public void setItem_cnt(int item_cnt) {
		this.item_cnt = item_cnt;
	}

	public String getDeli_status() {
		return deli_status;
	}

	public void setDeli_status(String deli_status) {
		this.deli_status = deli_status;
	}

	public String getRefund_status() {
		return refund_status;
	}

	public void setRefund_status(String refund_status) {
		this.refund_status = refund_status;
	}

	public int getRefund_request() {
		return refund_request;
	}

	public void setRefund_request(int refund_request) {
		this.refund_request = refund_request;
	}

}
