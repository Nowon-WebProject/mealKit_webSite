package kr.co.EZHOME.dto;

public class MyAddrDTO {
	private int my_deli_addr_seq;
	private String userid;
	private String my_deli_nick;
	private String my_deli_name;
	private String my_deli_addr;
	private String my_deli_phone;
	private String my_deli_msg;
	private String my_deli_pwd;

	public MyAddrDTO() {
		
		
	}

	public int getMy_deli_addr_seq() {
		return my_deli_addr_seq;
	}

	public void setMy_deli_addr_seq(int my_deli_addr_seq) {
		this.my_deli_addr_seq = my_deli_addr_seq;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getMy_deli_nick() {
		return my_deli_nick;
	}

	public void setMy_deli_nick(String my_deli_nick) {
		this.my_deli_nick = my_deli_nick;
	}

	public String getMy_deli_name() {
		return my_deli_name;
	}

	public void setMy_deli_name(String my_deli_name) {
		this.my_deli_name = my_deli_name;
	}

	public String getMy_deli_addr() {
		return my_deli_addr;
	}

	public void setMy_deli_addr(String my_deli_addr) {
		this.my_deli_addr = my_deli_addr;
	}

	public String getMy_deli_phone() {
		return my_deli_phone;
	}

	public void setMy_deli_phone(String my_deli_phone) {
		this.my_deli_phone = my_deli_phone;
	}

	public String getMy_deli_msg() {
		return my_deli_msg;
	}

	public void setMy_deli_msg(String my_deli_msg) {
		this.my_deli_msg = my_deli_msg;
	}

	public String getMy_deli_pwd() {
		return my_deli_pwd;
	}

	public void setMy_deli_pwd(String my_deli_pwd) {
		this.my_deli_pwd = my_deli_pwd;
	}
	
	
	
	
	
}
