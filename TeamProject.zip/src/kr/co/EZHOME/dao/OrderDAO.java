package kr.co.EZHOME.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import kr.co.EZHOME.dto.OrderDTO;
import kr.co.EZHOME.dto.PurchaseDTO;

public class OrderDAO {
	private static OrderDAO instance = new OrderDAO();

	public static OrderDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {
		Connection conn = null;
		Context initContext = new InitialContext();
		Context envContext = (Context) initContext.lookup("java:/comp/env");
		DataSource ds = (DataSource) envContext.lookup("jdbc/Oracle11g");
		conn = ds.getConnection();

		return conn;
	}

	public void insertOrder(OrderDTO odto) {
		String sql = "insert into ordertbl values(?,?,?,?,?,?,?,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, odto.getOrder_num());
			pstmt.setString(2, odto.getUserid());
			pstmt.setInt(3, odto.getItem_num());
			pstmt.setString(4, odto.getItem_name());
			pstmt.setInt(5, odto.getItem_price());
			pstmt.setInt(6, odto.getItem_cnt());
			pstmt.setString(7, odto.getDeli_status());
			pstmt.setString(8, odto.getRefund_status());
			pstmt.setInt(9, odto.getRefund_request());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public ArrayList<OrderDTO> selectOrderList(String order_num) {
		String sql = "select * from ordertbl where order_num=? order by item_num asc";
		ArrayList<OrderDTO> olist = new ArrayList<OrderDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, order_num);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				OrderDTO odto = new OrderDTO();
				odto.setOrder_num(rs.getString("order_num"));
				odto.setItem_num(rs.getInt("item_num"));
				odto.setItem_name(rs.getString("item_name"));
				odto.setItem_price(rs.getInt("item_price"));
				odto.setItem_cnt(rs.getInt("item_cnt"));
				odto.setDeli_status(rs.getString("deli_status"));
				odto.setRefund_status(rs.getString("refund_status"));
				odto.setRefund_request(rs.getInt("refund_request"));
				olist.add(odto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return olist;
	}

	public void modifyRefundStatus(int item_num, String refund_status, String order_num) {
		String sql = "update (select * from ordertbl where order_num=?) set refund_status=? where item_num=?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, order_num);
			pstmt.setString(2, refund_status);
			pstmt.setInt(3, item_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void addRequest(int refund_request, int item_num, String order_num) {
		String sql = "update ordertbl set refund_request=? where item_num=? and order_num=?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, refund_request);
			pstmt.setInt(2, item_num);
			pstmt.setString(3, order_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public ArrayList<OrderDTO> selectRefundRequest() {
		String sql = "select * from ordertbl where refund_request=1 order by order_num asc";
		ArrayList<OrderDTO> olist = new ArrayList<OrderDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				OrderDTO odto = new OrderDTO();
				odto.setOrder_num(rs.getString("order_num"));
				odto.setUserid(rs.getString("userid"));
				odto.setItem_num(rs.getInt("item_num"));
				odto.setItem_name(rs.getString("item_name"));
				odto.setItem_price(rs.getInt("item_price"));
				odto.setItem_cnt(rs.getInt("item_cnt"));
				odto.setDeli_status(rs.getString("deli_status"));
				odto.setRefund_status(rs.getString("refund_status"));
				olist.add(odto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return olist;
	}
	
	public void updateDeli_Status(String deli_status, String order_num) {
		String sql = "update ordertbl set deli_status=? where order_num=?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, deli_status);
			pstmt.setString(2, order_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
